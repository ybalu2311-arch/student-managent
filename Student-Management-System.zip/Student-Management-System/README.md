# Student Management System (React)

A beginner-friendly Student Management System built with React and Vite.

## Features

- View student records in a table
- Add a student
- Edit student details
- Delete a student (with confirmation)
- Search by student name, ID, or email
- Filter students by course
- Dashboard cards showing total students, courses, and first-year students
- Automatically saves records in the browser using `localStorage`
- Responsive layout for desktop and mobile

## Requirements

- Node.js (LTS recommended)
- npm

## Run in Visual Studio Code / PowerShell

1. Extract the ZIP file.
2. Open the extracted `Student-Management-System` folder in VS Code.
3. Open the terminal in that folder.
4. Install packages:

   ```powershell
   npm.cmd install
   ```

5. Start the development server:

   ```powershell
   npm.cmd run dev
   ```

6. Open the local URL printed in the terminal (usually `http://localhost:5173/`).

## Create a production build

```powershell
npm.cmd run build
```

## Main files

- `src/App.jsx` — components, state, form validation, search, filtering, and CRUD operations
- `src/index.css` — page styling and responsive layout
- `src/main.jsx` — React application entry point
- `index.html` — HTML page loaded by Vite

## Notes

- The project starts with three sample student records.
- Your changes are saved in the current browser's local storage.
- Use the browser's developer tools to clear local storage and restore the sample records.
