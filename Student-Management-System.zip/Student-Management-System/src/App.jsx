import { useEffect, useMemo, useState } from 'react';

const starterStudents = [
  { id: 'STU001', name: 'Aarav Sharma', email: 'aarav@example.com', course: 'Computer Science', year: '2nd Year', phone: '9876543210' },
  { id: 'STU002', name: 'Priya Reddy', email: 'priya@example.com', course: 'Electronics', year: '1st Year', phone: '9876501234' },
  { id: 'STU003', name: 'Rahul Kumar', email: 'rahul@example.com', course: 'Mechanical', year: '3rd Year', phone: '9867543210' },
];

const emptyForm = {
  name: '',
  email: '',
  course: 'Computer Science',
  year: '1st Year',
  phone: '',
};

function App() {
  const [students, setStudents] = useState(() => {
    try {
      const saved = localStorage.getItem('sms-students');
      return saved ? JSON.parse(saved) : starterStudents;
    } catch {
      return starterStudents;
    }
  });
  const [search, setSearch] = useState('');
  const [courseFilter, setCourseFilter] = useState('All Courses');
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [message, setMessage] = useState('');

  useEffect(() => {
    localStorage.setItem('sms-students', JSON.stringify(students));
  }, [students]);

  const filteredStudents = useMemo(() => {
    const term = search.trim().toLowerCase();
    return students.filter((student) => {
      const matchesSearch =
        student.name.toLowerCase().includes(term) ||
        student.id.toLowerCase().includes(term) ||
        student.email.toLowerCase().includes(term);
      const matchesCourse = courseFilter === 'All Courses' || student.course === courseFilter;
      return matchesSearch && matchesCourse;
    });
  }, [students, search, courseFilter]);

  const courses = ['Computer Science', 'Electronics', 'Mechanical', 'Civil', 'Business'];

  function openAddForm() {
    setEditingId(null);
    setForm(emptyForm);
    setShowForm(true);
    setMessage('');
  }

  function openEditForm(student) {
    setEditingId(student.id);
    setForm({
      name: student.name,
      email: student.email,
      course: student.course,
      year: student.year,
      phone: student.phone,
    });
    setShowForm(true);
    setMessage('');
  }

  function handleChange(event) {
    const { name, value } = event.target;
    setForm((current) => ({ ...current, [name]: value }));
  }

  function handleSubmit(event) {
    event.preventDefault();
    const cleanName = form.name.trim();
    const cleanEmail = form.email.trim();
    const cleanPhone = form.phone.trim();

    if (!cleanName || !cleanEmail || !cleanPhone) {
      setMessage('Please fill in all the fields.');
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      setMessage('Please enter a valid email address.');
      return;
    }
    if (!/^\d{10}$/.test(cleanPhone)) {
      setMessage('Phone number must contain exactly 10 digits.');
      return;
    }
    const duplicateEmail = students.some(
      (student) => student.email.toLowerCase() === cleanEmail.toLowerCase() && student.id !== editingId
    );
    if (duplicateEmail) {
      setMessage('A student with this email already exists.');
      return;
    }

    if (editingId) {
      setStudents((current) => current.map((student) =>
        student.id === editingId
          ? { ...student, ...form, name: cleanName, email: cleanEmail, phone: cleanPhone }
          : student
      ));
    } else {
      const nextNumber = students.reduce((max, student) => {
        const number = Number(student.id.replace('STU', '')) || 0;
        return Math.max(max, number);
      }, 0) + 1;
      const newStudent = {
        id: `STU${String(nextNumber).padStart(3, '0')}`,
        ...form,
        name: cleanName,
        email: cleanEmail,
        phone: cleanPhone,
      };
      setStudents((current) => [newStudent, ...current]);
    }
    setShowForm(false);
    setForm(emptyForm);
    setEditingId(null);
    setMessage('');
  }

  function deleteStudent(id) {
    const student = students.find((item) => item.id === id);
    if (window.confirm(`Delete ${student?.name || 'this student'}?`)) {
      setStudents((current) => current.filter((item) => item.id !== id));
    }
  }

  function closeForm() {
    setShowForm(false);
    setEditingId(null);
    setForm(emptyForm);
    setMessage('');
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark">S</div>
          <div>
            <strong>CampusFlow</strong>
            <span>STUDENT PORTAL</span>
          </div>
        </div>
        <div className="side-label">MENU</div>
        <div className="side-link active"><span className="side-icon">▦</span> Dashboard</div>
        <div className="side-link"><span className="side-icon">♙</span> Students</div>
        <div className="side-link"><span className="side-icon">▤</span> Courses</div>
        <div className="side-note">
          <div className="note-icon">✦</div>
          <strong>Stay organized</strong>
          <p>Manage student information from one simple dashboard.</p>
        </div>
        <div className="profile-mini">
          <div className="avatar admin-avatar">AD</div>
          <div><strong>Administrator</strong><span>Admin account</span></div>
        </div>
      </aside>

      <main className="main-content">
        <header className="topbar">
          <div className="breadcrumb">Workspace <span>/</span> <strong>Students</strong></div>
          <div className="topbar-right"><span className="online-dot"></span><span>Academic Portal</span><div className="avatar top-avatar">AD</div></div>
        </header>

        <section className="page-heading">
          <div>
            <p className="eyebrow">OVERVIEW</p>
            <h1>Student Management</h1>
            <p className="subtitle">Manage your student records, courses, and information.</p>
          </div>
          <button className="primary-button" onClick={openAddForm}><span>＋</span> Add New Student</button>
        </section>

        <section className="stats-grid">
          <div className="stat-card">
            <div className="stat-top"><span className="stat-icon purple">♙</span><span className="stat-caption">ALL STUDENTS</span></div>
            <div className="stat-number">{students.length}</div>
            <div className="stat-description">Registered student records</div>
          </div>
          <div className="stat-card">
            <div className="stat-top"><span className="stat-icon blue">▣</span><span className="stat-caption">COURSES</span></div>
            <div className="stat-number">{new Set(students.map((student) => student.course)).size}</div>
            <div className="stat-description">Courses represented</div>
          </div>
          <div className="stat-card">
            <div className="stat-top"><span className="stat-icon green">◷</span><span className="stat-caption">FIRST YEAR</span></div>
            <div className="stat-number">{students.filter((student) => student.year === '1st Year').length}</div>
            <div className="stat-description">Students in first year</div>
          </div>
        </section>

        <section className="content-card">
          <div className="table-heading">
            <div><h2>All Students</h2><p>View and manage all registered students.</p></div>
            <span className="record-count">{filteredStudents.length} RECORDS</span>
          </div>
          <div className="toolbar">
            <label className="search-box"><span>⌕</span><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search by name, ID or email..." /></label>
            <select className="filter-select" value={courseFilter} onChange={(event) => setCourseFilter(event.target.value)}>
              <option>All Courses</option>
              {courses.map((course) => <option key={course}>{course}</option>)}
            </select>
          </div>

          <div className="table-wrap">
            <table>
              <thead><tr><th>STUDENT</th><th>STUDENT ID</th><th>COURSE</th><th>YEAR</th><th>PHONE</th><th className="actions-heading">ACTIONS</th></tr></thead>
              <tbody>
                {filteredStudents.map((student, index) => (
                  <tr key={student.id}>
                    <td><div className="student-cell"><div className={`avatar student-avatar avatar-${index % 4}`}>{student.name.split(' ').map((part) => part[0]).slice(0, 2).join('').toUpperCase()}</div><div><strong>{student.name}</strong><span>{student.email}</span></div></div></td>
                    <td><span className="student-id">{student.id}</span></td>
                    <td>{student.course}</td>
                    <td><span className="year-pill">{student.year}</span></td>
                    <td>{student.phone}</td>
                    <td><div className="action-buttons"><button className="edit-button" onClick={() => openEditForm(student)} aria-label={`Edit ${student.name}`} title="Edit">✎</button><button className="delete-button" onClick={() => deleteStudent(student.id)} aria-label={`Delete ${student.name}`} title="Delete">×</button></div></td>
                  </tr>
                ))}
                {filteredStudents.length === 0 && <tr><td colSpan="6"><div className="empty-state"><div>⌕</div><strong>No students found</strong><span>Try another search or add a new student.</span></div></td></tr>}
              </tbody>
            </table>
          </div>
          <div className="table-footer"><span>Showing <strong>{filteredStudents.length}</strong> of <strong>{students.length}</strong> students</span><span>Changes are saved automatically</span></div>
        </section>
        <footer className="footer">© 2026 CampusFlow <span>•</span> Student Management System</footer>
      </main>

      {showForm && (
        <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) closeForm(); }}>
          <section className="modal" role="dialog" aria-modal="true" aria-labelledby="form-title">
            <div className="modal-heading"><div><p className="eyebrow">STUDENT RECORD</p><h2 id="form-title">{editingId ? 'Edit Student' : 'Add New Student'}</h2><p>Enter the student details below.</p></div><button className="close-button" onClick={closeForm} aria-label="Close">×</button></div>
            <form onSubmit={handleSubmit}>
              <div className="form-grid">
                <label>Full Name<input name="name" value={form.name} onChange={handleChange} placeholder="Enter full name" autoFocus /></label>
                <label>Email Address<input name="email" type="email" value={form.email} onChange={handleChange} placeholder="student@example.com" /></label>
                <label>Course<select name="course" value={form.course} onChange={handleChange}>{courses.map((course) => <option key={course}>{course}</option>)}</select></label>
                <label>Academic Year<select name="year" value={form.year} onChange={handleChange}><option>1st Year</option><option>2nd Year</option><option>3rd Year</option><option>4th Year</option></select></label>
                <label className="full-width">Phone Number<input name="phone" value={form.phone} onChange={handleChange} placeholder="10-digit phone number" maxLength="10" inputMode="numeric" /></label>
              </div>
              {message && <p className="form-message">{message}</p>}
              <div className="modal-actions"><button type="button" className="secondary-button" onClick={closeForm}>Cancel</button><button type="submit" className="primary-button">{editingId ? 'Save Changes' : 'Add Student'}</button></div>
            </form>
          </section>
        </div>
      )}
    </div>
  );
}

export default App;
